#!/usr/bin/env python3
import os, time, requests, socket, threading, dns.resolver

#======================
# COLORS
#======================

RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
BLUE   = "\033[94m"
CYAN   = "\033[96m"
RESET  = "\033[0m"

#======================
# CLEAR SCREEN
#======================

def clear():
    os.system("clear")

#======================
# BANNER
#======================

def banner():
    art = [
        "  █████╗ ██╗  ██╗███╗   ███╗███████╗██████╗ ",
        " ██╔══██╗██║  ██║████╗ ████║██╔════╝██╔══██╗",
        " ███████║███████║██╔████╔██║█████╗  ██████╔╝",
        " ██╔══██║██╔══██║██║╚██╔╝██║██╔══╝  ██╔══██╗",
        " ██║  ██║██║  ██║██║ ╚═╝ ██║███████╗██║  ██║",
        " ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝",
        "",
        "        Dv.Ahmed — Web Scanner Pro"
    ]
    for line in art:
        print(CYAN + line + RESET)
        time.sleep(0.04)

#======================
# SAVE RESULTS
#======================

def save_result(text):
    with open("results.txt", "a") as f:
        f.write(text + "\n")

#======================
# URL SCANNER
#======================

def url_scanner(url):
    print(BLUE + " [+] URL Scanning..." + RESET)
    try:
        r = requests.get(url)
        print(GREEN + f"[URL] Status Code: {r.status_code}" + RESET)
        save_result(f"URL Scan: {url} → {r.status_code}")
    except:
        print(RED + "[URL] Error connecting." + RESET)

#======================
# PORT SCANNER
#======================

def port_scan(host):
    print(BLUE + " [+] Port scanning..." + RESET)
    ports = [21,22,23,25,53,80,110,135,443,445,8080]

    for p in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            result = s.connect_ex((host, p))

            if result == 0:
                print(GREEN + f"[OPEN] Port {p}" + RESET)
                save_result(f"Open Port: {p}")
            else:
                print(RED + f"[CLOSED] Port {p}" + RESET)
            s.close()
        except:
            pass

#======================
# SUBDOMAIN SCANNER
#======================

def subdomain_scan(domain):
    print(BLUE + " [+] Subdomain scanning..." + RESET)
    common = ["www", "mail", "ftp", "cpanel", "webmail", "test"]

    for sub in common:
        full = f"{sub}.{domain}"
        try:
            dns.resolver.resolve(full, 'A')
            print(GREEN + f"[FOUND] {full}" + RESET)
            save_result(f"Subdomain: {full}")
        except:
            print(RED + f"[NO] {full}" + RESET)

#======================
# XSS TESTER
#======================

def xss_test(url):
    print(BLUE + " [+] XSS Testing..." + RESET)
    payload = "<script>alert('XSS')</script>"

    try:
        r = requests.get(url + payload)
        if payload in r.text:
            print(GREEN + "[XSS] Vulnerable ✓" + RESET)
            save_result(f"XSS Vulnerable: {url}")
        else:
            print(RED + "[XSS] Not Vulnerable" + RESET)
    except:
        print(RED + "[XSS] Request Failed" + RESET)

#======================
# SQLi TESTER
#======================

def sqli_test(url):
    print(BLUE + " [+] SQL Injection Testing..." + RESET)
    payload = "' OR '1'='1"

    try:
        r = requests.get(url + payload)
        errors = ["sql", "syntax", "mysql", "error"]
        if any(e in r.text.lower() for e in errors):
            print(GREEN + "[SQLi] Vulnerable ✓" + RESET)
            save_result(f"SQLi Vulnerable: {url}")
        else:
            print(RED + "[SQLi] Not Vulnerable" + RESET)
    except:
        print(RED + "[SQLi] Request Failed" + RESET)

#======================
# SPEED TEST
#======================

def speed_scan(url):
    print(BLUE + " [+] Speed scanning... (10 threads)" + RESET)

    def worker():
        try:
            requests.get(url)
        except:
            pass

    threads = []
    for i in range(10):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    print(GREEN + "[+] Speed test complete." + RESET)
    save_result("Speed Scan Completed")

#======================
# MENU
#======================

def menu():
    clear()
    banner()
    print(YELLOW + " ===== MENU =====" + RESET)
    print(CYAN + "1) URL Scanner")
    print("2) Port Scanner")
    print("3) Subdomain Scanner")
    print("4) XSS Test")
    print("5) SQLi Test")
    print("6) Speed Scan")
    print("7) FULL Scan")
    print("0) Exit" + RESET)

#======================
# MAIN LOOP
#======================

while True:
    menu()
    choice = input(GREEN + " Dooro (0-7): " + RESET)

    if choice == "0":
        print(RED + "Exiting..." + RESET)
        break

    url = input(CYAN + "Gali URL (https://example.com): " + RESET)
    domain = url.replace("https://", "").replace("http://", "").split("/")[0]

    if choice == "1":
        url_scanner(url)
    elif choice == "2":
        port_scan(domain)
    elif choice == "3":
        subdomain_scan(domain)
    elif choice == "4":
        xss_test(url + "?q=")
    elif choice == "5":
        sqli_test(url + "?id=")
    elif choice == "6":
        speed_scan(url)
    elif choice == "7":
        url_scanner(url)
        port_scan(domain)
        subdomain_scan(domain)
        xss_test(url + "?q=")
        sqli_test(url + "?id=")
        speed_scan(url)
    else:
        print(RED + "Invalid option!" + RESET)

    input(YELLOW + "Press Enter to continue..." + RESET)
